"""SDS Data Model."""
